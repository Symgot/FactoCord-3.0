# Security Policy

## Supported Versions

Only latest master version currently supported.

## Reporting a Vulnerability

[Open issue on github](https://github.com/maxsupermanhd/FactoCord-3.0/issues)
or DM MaX#6717 in Discord 
